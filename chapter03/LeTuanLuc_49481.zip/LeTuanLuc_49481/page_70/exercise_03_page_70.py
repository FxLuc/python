"""
Author: Le Tuan Luc
Date: 2021/07/19
Program: exercise_03_page_70.py
Problem:
    Explain the role of the variable in the header of a for loop.
Solution:
    The for loop consists of a header and a set of statements called the body.
    The header contains information that controls the number of times that the body executes.
"""