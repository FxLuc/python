"""
Author: Le Tuan Luc
Date: 2021/07/20
Program: exercise_07_page_85.py
Problem:
    Explain the role of the trailing else part of an extended if statement.
Solution:
    If a condition is not right, do something else.
"""