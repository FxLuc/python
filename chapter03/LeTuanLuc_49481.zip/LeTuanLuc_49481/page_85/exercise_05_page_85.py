"""
Author: Le Tuan Luc
Date: 2021/07/20
Program: exercise_05_page_85.py
Problem:
    Explain how to check for an invalid input number and prevent it being used in a program. You may assume that the user enters a number.
Solution:
    if (type(<variable>) is <int/long/float>)
"""