"""
Author: Le Tuan Luc
Date: 2021/07/19
Program: exercise_01_page_72.py
Problem:
    Assume that the variable amount refers to 24.325. Write the outputs of the following statements:
        a. print("Your salary is $%0.2f" % amount)
        b. print("The area is %0.1f" % amount)
        c. print("%7f" % amount)
Solution:
    a. Your salary is $24.32
    b. The area is 24.3
    c. 24.325000
"""