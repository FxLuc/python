"""
Author: Le Tuan Luc
Date: 2021/07/20
Program: exercise_06_page_92.py
Problem:
    What happens when the programmer forgets to update the loop control variable in a while loop?
Solution:
    The loop runs for infinite times.
"""