"""
Author: Le Tuan Luc
Date: 2021/07/02
Program: page_009_exercises_02.py
Problem:
    What does the central processing unit (CPU) do?
Solution:
    Process all the data and instructions that make the computer system work.
    It performs the basic arithmetical, logical, and input/output operations of a computer system.
"""