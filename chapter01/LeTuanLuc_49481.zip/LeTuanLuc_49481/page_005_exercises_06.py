"""
Author: Le Tuan Luc
Date: 2021/07/02
Program: page_005_exercises_06.py
Problem:
    List four devices that use computers and describe the information that they process.
Solution:
    - Microphone, camera covert information such as images, sound to data for computational processing.
    - Monitor, speaker covert the data of computational processing back to human-usable form.
"""