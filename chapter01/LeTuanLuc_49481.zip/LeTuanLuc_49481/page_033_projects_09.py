"""
Author: Le Tuan Luc
Date: 2021/07/03
Program: page_033_projects_09.py
Problem:
    Enter an input statement using the input function at the shell prompt.
    When the prompt asks you for input, enter your first name, observe the results, and explain what happened.
Solution:
    1. Stopped program until the user has given an input.
    2. Convert value into a string.
    3. Return value.
"""
input('Enter any: ')