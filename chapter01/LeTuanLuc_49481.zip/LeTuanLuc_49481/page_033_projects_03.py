"""
Author: Le Tuan Luc
Date: 2021/07/03
Program: page_033_projects_03.py
Problem:
    Evaluate the following code at a shell prompt: print ("Your name is", name).
    Then assign name an appropriate value, and evaluate the statement again.
Solution:
    >>>
"""
name = input('Enter your name: ')
print('Your name is:', name)