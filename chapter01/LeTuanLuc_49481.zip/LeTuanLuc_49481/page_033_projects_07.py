"""
Author: Le Tuan Luc
Date: 2021/07/03
Program: page_033_projects_07.py
Problem:
    Write and test a program that accepts the user’s name (as text) and age (as a number)as input.
    The program should output a sentence containing the user’s name and age.
Solution:
    >>>
"""
name = input('Enter your name: ')
age = int(input('Enter your age: '))
print(f"Hi!My name is {name}. I'm {age} year old.")