"""
Author: Le Tuan Luc
Date: 2021/07/03
Program: page_033_projects_02.py
Problem:
    Write a Python program that prints (displays) your name, address, and telephone number.
Solution:
    >>>
"""
name = input('Enter your name: ')
address = input('Enter your address: ')
tel = input('Enter your telephone number: ')
print('Your name is:', name)
print('Your address is:', address)
print('Your telephone number is:', tel)