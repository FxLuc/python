"""
Author: Le Tuan Luc
Date: 2021/07/02
Program: page_009_exercises_01.py
Problem:
    List two examples of input devices and two examples of output devices.
Solution:
    Input devices: a keyboard, a mouse.
    Output devices: a monitor, speakers.
"""