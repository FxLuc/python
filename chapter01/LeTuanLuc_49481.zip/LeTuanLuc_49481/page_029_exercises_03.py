"""
Author: Le Tuan Luc
Date: 2021/07/03
Program: page_029_exercises_03.py
Problem:
    Answer the question, What is a Python script?
Solution:
    Python scripts are programs that are saved in files and run from a terminal command prompt.
    An interactive script consists of a set of input statements, statements that process these inputs, and statements that output the results.
"""