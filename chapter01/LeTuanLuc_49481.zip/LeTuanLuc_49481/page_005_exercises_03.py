"""
Author: Le Tuan Luc
Date: 2021/07/02
Program: page_005_exercises_03.py
Problem:
    Write an algorithm that describes a common task, such as baking a cake or operating a DVD player.
Solution:
    1. Push a button to open disc drive.
    2. Put disc into disc drive.
    3. Press the button again and wait it close.
"""