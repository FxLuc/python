"""
Author: Le Tuan Luc
Date: 2021/07/03
Program: page_033_projects_05.py
Problem:
    Modify the program of Project 4 to compute the area of a triangle.
    Issue the appropriate prompts for the triangle’s base and height, and change the names of the variables appropriately.
    Then, use the formula .5 * base * height to compute the area.
    -> computes the area of a triangle.
Solution:
    >>>
"""
height = float(input('Enter height of triangle: '))
base = float(input('Enter base of triangle: '))
print('The area of a triangle =', .5 * base * height)