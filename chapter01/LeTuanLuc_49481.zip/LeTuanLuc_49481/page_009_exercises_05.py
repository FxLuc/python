"""
Author: Le Tuan Luc
Date: 2021/07/03
Program: page_009_exercises_05.py
Problem:
    What role do translators play in the programming process?
Solution:
    Convert the high-level program code into executable code.
"""