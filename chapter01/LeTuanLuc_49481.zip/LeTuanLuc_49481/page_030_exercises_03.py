"""
Author: Le Tuan Luc
Date: 2021/07/03
Program: page_030_exercises_03.py
Problem:
    Why does Python code generate fewer types of syntax errors than code in other programming languages?
Solution:
    Because the Python language is much simpler than other programming languages.
"""