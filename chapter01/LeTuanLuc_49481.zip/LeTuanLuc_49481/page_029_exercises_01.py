"""
Author: Le Tuan Luc
Date: 2021/07/03
Program: page_029_exercises_01.py
Problem:
    Describe what happens when the programmer enters the string "Greetings!" in the Python shell.
Solution:
    Python evaluates it and displays its result (print('Greeting!')), if there is one, followed by a new prompt.
"""