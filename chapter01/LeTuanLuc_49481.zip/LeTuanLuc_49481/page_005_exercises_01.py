"""
Author: Le Tuan Luc
Date: 2021/07/02
Program: page_005_exercises_01.py
Problem:
    List three common types of computing agents.
Solution:
    1. CPU
    2. Memory
    3. Output/input devices
"""