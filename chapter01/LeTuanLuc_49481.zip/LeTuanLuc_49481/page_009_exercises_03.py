"""
Author: Le Tuan Luc
Date: 2021/07/03
Program: page_009_exercises_03.py
Problem:
    How is information represented in hardware memory?
Solution:
    Information is stored as patterns of binary digits (1s and 0s).
"""