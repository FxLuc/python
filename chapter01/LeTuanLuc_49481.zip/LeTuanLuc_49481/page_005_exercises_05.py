"""
Author: Le Tuan Luc
Date: 2021/07/02
Program: page_005_exercises_05.py
Problem:
    In what sense is a laptop computer a general-purpose problem-solving machine?
Solution:
    Capable of performing a task described by any algorithm.
"""