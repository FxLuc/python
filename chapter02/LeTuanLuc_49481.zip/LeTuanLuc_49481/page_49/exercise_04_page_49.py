"""
Author: Le Tuan Luc
Date: 2021/07/13
Program: exercise_04_page_49.py
Problem:
    Write the ASCII values of the characters '$' and '&'.
Solution:
    $: 36
    &: 38
"""