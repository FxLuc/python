"""
Author: Le Tuan Luc
Date: 2021/07/13
Program: exercise_02_page_49.py
Problem:
    Explain the differences between the data types int and float.
Solution:
    The int data type represents integers.
    The float data type represents floating-point numbers.
"""