"""
Author: Le Tuan Luc
Date: 2021/07/13
Program: exercise_02_page_54.py
Problem:
    Let x = 4.66 Write the values of the following expressions:
        a. round(x)
        b. int(x)
Solution:
    a. 5
    b. 4
"""