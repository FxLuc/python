"""
Author: Le Tuan Luc
Date: 2021/07/13
Program: exercise_01_page_53.py
Problem:
    Let x = 8 and y = 2. Write the values of the following expressions:
        a. x + y * 3
        b. (x + y) * 3
        c. x ** y
        d. x % y
        e. x / 12.0
        f. x // 6
Solution:
    a. 14
    b. 30
    c. 64
    d. 0
    e. 0.6666666666666666
    f. 1
"""