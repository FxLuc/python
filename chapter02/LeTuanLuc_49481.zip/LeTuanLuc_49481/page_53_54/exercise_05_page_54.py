"""
Author: Le Tuan Luc
Date: 2021/07/13
Program: exercise_05_page_54.py
Problem:
    Assume that the variable x has the value 55. Use an assignment statement to increment the value of x by 1
Solution:
    x += 1
"""