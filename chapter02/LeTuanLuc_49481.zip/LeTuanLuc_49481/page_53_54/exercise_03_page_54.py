"""
Author: Le Tuan Luc
Date: 2021/07/13
Program: exercise_03_page_54.py
Problem:
    How does a Python programmer round a float value to the nearest int value?
Solution:
    Use function round()
    If the number after the decimal place given
        >=5 than + 1 will be added to the final value
        <5 than the final value will return as it is up to the decimal places mentioned.
"""