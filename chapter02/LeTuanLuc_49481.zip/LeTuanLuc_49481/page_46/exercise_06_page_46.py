"""
Author: Le Tuan Luc
Date: 2021/07/12
Program: exercise_06_page_46.py
Problem:
    List two of the purposes of program documentation.
Solution:
    - The author of a program can include his or her name.
    - A brief statement about the program’s purpose.
"""