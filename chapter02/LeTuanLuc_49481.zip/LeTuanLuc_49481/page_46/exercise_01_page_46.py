"""
Author: Le Tuan Luc
Date: 2021/07/12
Program: exercise_01_page_46.py
Problem:
    Let the variable x be "dog" and the variable y be "cat". Write the values returned by the following operations:
        a. x + y
        b. "the " + x + " chases the " + y
        c. x * 4
Solution:
    a. dogcat
    b. the dog chases the cat
    c. dogdogdogdog
"""

# variable
x = 'dog'
y = 'cat'

# a
print(x + y)

# b
print("the " + x + " chases the " + y)

# c
print(x * 4)
