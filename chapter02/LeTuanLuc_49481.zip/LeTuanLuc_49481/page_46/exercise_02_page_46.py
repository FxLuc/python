"""
Author: Le Tuan Luc
Date: 2021/07/12
Program: exercise_02_page_46.py
Problem:
    Write a string that contains your name and address on separate lines using embedded newline characters.
    Then write the same string literal without the newline characters.
Solution:
    When evaluate a string in the Python shell without the print function, the literal for the newline character embedded in the result.
    >>>
"""

print("Hi! My name is Luc.\nI living in Da Nang city.")

print("""Hi! My name is Luc.
I living in Da Nang city.""")