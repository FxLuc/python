"""
Author: Le Tuan Luc
Date: 2021/07/12
Program: exercise_03_page_46.py
Problem:
    How does one include an apostrophe as a character within a string literal?
Solution:
    Use \'
"""