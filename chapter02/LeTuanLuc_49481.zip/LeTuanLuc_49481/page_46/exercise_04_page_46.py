"""
Author: Le Tuan Luc
Date: 2021/07/12
Program: exercise_04_page_46.py
Problem:
    What happens when the print function prints a string literal with embedded newline characters?
Solution:
    Add a newline characters.
"""