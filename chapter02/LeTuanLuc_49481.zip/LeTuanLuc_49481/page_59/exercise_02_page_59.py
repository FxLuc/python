"""
Author: Le Tuan Luc
Date: 2021/07/13
Program: exercise_02_page_59.py
Problem:
    Write a code segment that imports this function and calls it to print the values 8^2 and 5^4.
Solution:
    >>>
"""

print(pow(8,2))
print(pow(5,4))