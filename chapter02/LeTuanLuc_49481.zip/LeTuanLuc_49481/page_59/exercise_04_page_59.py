"""
Author: Le Tuan Luc
Date: 2021/07/13
Program: exercise_04_page_59.py
Problem:
    Explain how to display help information on a particular function in a given module.
Solution:
    1. Open terminal.
    2. Navigate or change directories until the prompt shows attached to the directory that contains the Python script.
    3. python
    4. >>> help("script_name")
"""