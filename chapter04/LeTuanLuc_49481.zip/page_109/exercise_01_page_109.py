"""
Author: Le Tuan Luc
Date: 2021/08/02
Program: exercise_01_page_109.py
Problem:
    Write the encrypted text of each of the following words using a Caesar cipher with a distance value of 3:
        a. python
        b. hacker
        c. wow
Solution:
    a. sbwkrq
    b. kdfnhu
    c. zrz
"""
