"""
Author: Le Tuan Luc
Date: 2021/08/02
Program: exercise_01_page_106.py
Problem:
    Assume that the variable data refers to the string "myprogram.exe". Write the values of the following expressions:
        a. data[2]
        b. data[-1]
        c. len(data)
        d. data[0:8]
Solution:
    a. p
    b. e
    c. 13
    d. myprogra
"""
data = "myprogram.exe"
print(data[2])
print(data[-1])
print(len(data))
print(data[0:8])