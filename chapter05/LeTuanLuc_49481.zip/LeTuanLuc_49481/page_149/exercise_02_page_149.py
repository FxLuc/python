"""
Author: Le Tuan Luc
Date: 2021/08/11
Program: exercise_02_page_149.py
Problem:
    Define a function named even. This function expects a number as an argument and returns True if the number is divisible by 2, or it returns False otherwise.
    (Hint: A number is evenly divisible by 2 if the remainder is 0.)
Solution:
    >>>
"""
def even(number):
    if (number % 2 == 0):
        return True
    return False