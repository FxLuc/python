"""
Author: Le Tuan Luc
Date: 2021/08/11
Program: exercise_01_page_149.py
Problem:
    What roles do the parameters and the return statement play in a function definition?
Solution:
    The return statement returns a value from a function definition.
"""