"""
Author: Le Tuan Luc
Date: 2021/08/11
Program: exercise_04_page_146.py
Problem:
    Write a loop that accumulates the sum of the numbers in a list named data
Solution:
    >>>
"""
data = [5, 3, 7]
sum = 0
for element in data:
    sum += element
print(sum)