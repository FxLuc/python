"""
Author: Le Tuan Luc
Date: 2021/08/11
Program: exercise_01_page_158.py
Problem:
    Give three examples of real-world objects that behave like a dictionary
Solution:
    1. Book
    2. Phonebook
    3. Bookshelf
"""